import math
n, m = map(int, input().split())
res = math.pow(2, n) + pow(3, m)
ans = str(res)
print(ans[0])
